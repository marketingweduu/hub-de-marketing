# Hub de Marketing — Weduu e Netpartners

Site estático (HTML + JS) com login Google, Firestore e Storage no Firebase (projeto `hub-de-marketing-8a828`).

## Estrutura
- `hub/` — arquivos que vão para o servidor em `weduu.com/hub/`
- `firebase/firestore.rules` e `firebase/storage.rules` — regras (publicadas pelo console do Firebase)

## Testar no computador
Dentro da pasta `hub/`: `python3 -m http.server 8080` e abrir `http://localhost:8080/login.html`.
O `localhost` já é domínio autorizado no login do Firebase. Atenção: usa os dados reais do Firebase.

## Publicar
1. Copiar o conteúdo de `hub/` para `httpdocs/hub` no servidor (WP File Manager), substituindo os arquivos.
2. Mudou regra? Colar o arquivo de `firebase/` em Firebase > Firestore/Storage > Regras e clicar em Publicar.

## Não colocar aqui
- `importar-usuarios.html` e `usuarios-iniciais.json` (e-mails da equipe).
- Dados do Financeiro: os lançamentos ficam só no Firestore (`financeiro.html` aqui vai sem os dados).
