/* Dados do app Web "Hub de Marketing" (projeto hub-de-marketing-8a828).
   Esses valores NÃO são segredos: quem protege os dados são as regras do Firestore e do Storage. */
window.HUB_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAxxKBKRjZCpjt_FZ8OwWwwSYT8LMq4caI",
  authDomain: "hub-de-marketing-8a828.firebaseapp.com",
  projectId: "hub-de-marketing-8a828",
  storageBucket: "hub-de-marketing-8a828.firebasestorage.app",
  messagingSenderId: "639796450922",
  appId: "1:639796450922:web:086fdf974b812bc789dc13"
};
