/* Liga o HubDB ao Firebase nas páginas que não fazem o login (hub, porta-voz, pastas, solicitação).
   Nas páginas protegidas (data-protegida="1"): sem sessão válida, volta para o login;
   se a sessão do Firebase existe mas o acesso ainda não estava guardado, recarrega uma vez já com ele. */
(function () {
  if (!(window.HubDBFirebase && window.HUB_FIREBASE_CONFIG)) return;
  var s = document.currentScript, prot = s && s.getAttribute('data-protegida') === '1';
  var tem = false; try { tem = !!localStorage.getItem('hub_acesso'); } catch (e) {}
  if (prot && !tem) document.documentElement.style.visibility = 'hidden';
  HubDBFirebase.iniciar({ firebaseConfig: window.HUB_FIREBASE_CONFIG }).then(function (a) {
    if (!prot) return;
    if (!a) location.replace('login.html'); else if (!tem) location.reload();
  }, function () { if (prot) location.replace('login.html'); });
})();
