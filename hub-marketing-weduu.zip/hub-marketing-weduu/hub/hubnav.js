/* Barra de navegação comum: "← Voltar" + "Sair da conta" (quando há login).
   Uso: <script src="hubnav.js" data-voltar="weduu.html" data-rotulo="Voltar ao site"></script> */
(function () {
  var s = document.currentScript;
  var destino = (s && s.getAttribute('data-voltar')) || '';
  var rotulo = (s && s.getAttribute('data-rotulo')) || 'Voltar';
  var semSair = s && s.getAttribute('data-sem-sair') === '1';
  var semVoltar = s && s.getAttribute('data-sem-voltar') === '1';
  function acesso() { try { var a = JSON.parse(localStorage.getItem('hub_acesso')); return a && a.marcas ? a : null; } catch (e) { return null; } }

  var css = document.createElement('style');
  css.textContent =
    '#hubnav{position:relative;z-index:2147483000;display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:38px;padding:6px 18px;' +
    'background:#14141a;color:#fff;font:500 13px/1.2 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}' +
    '#hubnav a,#hubnav button{color:#fff;background:rgba(255,255,255,.12);border:0;border-radius:999px;padding:7px 14px;font:inherit;text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;gap:6px}' +
    '#hubnav a:hover,#hubnav button:hover{background:rgba(255,255,255,.22)}' +
    '#hubnav .quem{opacity:.8;margin-right:10px}#hubnav .dir{display:flex;align-items:center}';
  document.head.appendChild(css);

  var bar = document.createElement('div');
  bar.id = 'hubnav';
  var esq = document.createElement('a');
  esq.href = destino || '#';
  esq.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>'; esq.appendChild(document.createTextNode(rotulo));
  if (!destino) esq.addEventListener('click', function (e) { e.preventDefault(); if (history.length > 1) history.back(); });
  if (!semVoltar) bar.appendChild(esq); else bar.appendChild(document.createElement('span'));

  var dir = document.createElement('div'); dir.className = 'dir';
  var a = acesso();
  if (a && !semSair) {
    var q = document.createElement('span'); q.className = 'quem'; q.textContent = a.nome || '';
    var b = document.createElement('button'); b.type = 'button'; b.textContent = 'Sair da conta';
    b.addEventListener('click', function () {
      var ir = function () { location.href = 'index.html'; };
      try { if (window.HubDB && HubDB.sair) { Promise.resolve(HubDB.sair()).then(ir, ir); return; } localStorage.removeItem('hub_acesso'); } catch (e) {}
      ir();
    });
    dir.appendChild(q); dir.appendChild(b);
  }
  bar.appendChild(dir);
  if (semVoltar && !(dir.firstChild)) return;
  document.body.insertBefore(bar, document.body.firstChild);
})();
