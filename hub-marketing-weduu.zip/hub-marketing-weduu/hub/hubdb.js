/* HubDB — base de dados compartilhada entre os sites públicos e o hub interno.
   NESTA VERSÃO DE TESTE: metadados em localStorage, arquivos em IndexedDB (mesmo navegador).
   NA VERSÃO FINAL: este arquivo é trocado por Firestore (metadados) + Firebase Storage (arquivos),
   mantendo os mesmos nomes de função. Toda gravação leva o campo `marca`. */
(function () {
  var K = 'hub_db_v1';
  var MEM = null;
  var MARCAS = { weduu: 'Weduu', netpartners: 'Netpartners' };
  var PASTAS = {
    marca: 'Marca',
    institucional: 'Materiais institucionais',
    cases: 'Cases & Histórias',
    ajuda: 'Central de Ajuda',
    divulgacao: 'Materiais de Divulgação'
  };

  function vazio() { return { materiais: [], solicitacoes: [], aprovacoes: {} }; }
  function readLocal() {
    var d = null;
    try { var raw = localStorage.getItem(K); if (raw) d = JSON.parse(raw); } catch (e) { d = MEM; }
    if (!d) d = MEM || vazio();
    d.materiais = d.materiais || []; d.solicitacoes = d.solicitacoes || []; d.aprovacoes = d.aprovacoes || {};
    return d;
  }
  function writeLocal(d) {
    MEM = d;
    try { localStorage.setItem(K, JSON.stringify(d)); } catch (e) { /* sem armazenamento: fica só em memória */ }
    return d;
  }
  /* Camada de armazenamento trocável: na versão final, firebase/hubdb-firebase.js chama HubDB._usarStore(...)
     e passa a ler/gravar no Firestore/Storage sem mudar nenhuma outra função deste arquivo. */
  var read = readLocal, write = writeLocal, semSeed = false;
  var rawFn = function () { try { return localStorage.getItem(K) || ''; } catch (e) { return JSON.stringify(MEM || ''); } };
  function uid(p) { return p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function agora() { return new Date().toISOString(); }

  /* ---------- arquivos (IndexedDB) ---------- */
  function idb() {
    return new Promise(function (ok, fail) {
      try {
        var r = indexedDB.open('hub_arquivos', 1);
        r.onupgradeneeded = function () { r.result.createObjectStore('f'); };
        r.onsuccess = function () { ok(r.result); };
        r.onerror = function () { fail(r.error); };
      } catch (e) { fail(e); }
    });
  }
  function idbPut(id, blob) {
    return idb().then(function (db) {
      return new Promise(function (ok, fail) {
        var t = db.transaction('f', 'readwrite'); t.objectStore('f').put(blob, id);
        t.oncomplete = function () { ok(); }; t.onerror = function () { fail(t.error); };
      });
    });
  }
  function idbGet(id) {
    return idb().then(function (db) {
      return new Promise(function (ok, fail) {
        var q = db.transaction('f').objectStore('f').get(id);
        q.onsuccess = function () { ok(q.result || null); }; q.onerror = function () { fail(q.error); };
      });
    });
  }
  function idbDel(id) {
    return idb().then(function (db) {
      return new Promise(function (ok) {
        var t = db.transaction('f', 'readwrite'); t.objectStore('f').delete(id);
        t.oncomplete = function () { ok(); }; t.onerror = function () { ok(); };
      });
    }).catch(function () {});
  }

  var putBlob = idbPut, getBlob = idbGet, delBlob = idbDel;

  window.HubDB = {
    MARCAS: MARCAS, PASTAS: PASTAS,
    _usarStore: function (x) {
      if (x.read) read = x.read; if (x.write) write = x.write; if (x.raw) rawFn = x.raw;
      if (x.putBlob) putBlob = x.putBlob; if (x.getBlob) getBlob = x.getBlob; if (x.delBlob) delBlob = x.delBlob;
      if (x.semSeed) semSeed = true;
    },
    read: read,
    raw: function () { return rawFn(); },

    /* Materiais: sobe para a pasta de UMA marca */
    addMaterial: function (marca, pasta, file, por) {
      if (!MARCAS[marca]) return Promise.reject(new Error('Marca inválida'));
      if (!PASTAS[pasta]) return Promise.reject(new Error('Pasta inválida'));
      var id = uid('m');
      var caminho = 'materiais/' + marca + '/' + pasta + '/' + id + '-' + String(file.name || 'arquivo').replace(/[^\w.\-]+/g, '_');
      return putBlob(id, file, caminho).then(function () {
        var d = read();
        var m = { id: id, marca: marca, pasta: pasta, nome: file.name, tipo: file.type || '', tamanho: file.size, por: por || '', em: agora(), caminho: caminho };
        d.materiais.unshift(m); write(d); return m;
      });
    },
    removeMaterial: function (id) {
      var d = read(); d.materiais = d.materiais.filter(function (m) { return m.id !== id; }); write(d); return delBlob(id);
    },
    materiais: function (marca, pasta) {
      return read().materiais.filter(function (m) { return m.marca === marca && (!pasta || m.pasta === pasta); });
    },
    getBlob: function (id) { return getBlob(id); },

    /* Solicitações vindas do site público */
    addSolicitacao: function (s) {
      var d = read();
      var n = d.solicitacoes.length + 1;
      var r = {
        id: uid('s'), protocolo: semSeed ? 'SOL-' + agora().slice(2, 10).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 6).toUpperCase() : 'SOL-' + String(n).padStart(4, '0'),
        marca: s.marca, nome: s.nome, email: s.email, tipo: s.tipo, titulo: s.titulo, descricao: s.descricao || '', prazo: s.prazo || '',
        origem: s.origem || 'Site público', status: 'Nova', lida: false, em: agora()
      };
      d.solicitacoes.unshift(r); write(d); return r;
    },
    solicitacoes: function (marca) { return read().solicitacoes.filter(function (s) { return s.marca === marca; }); },
    setSolicitacao: function (id, patch) {
      var d = read(); d.solicitacoes = d.solicitacoes.map(function (s) { return s.id === id ? Object.assign({}, s, patch) : s; }); write(d);
    },
    marcarLidas: function (marca) {
      var d = read(), mudou = false;
      d.solicitacoes.forEach(function (s) { if (s.marca === marca && !s.lida) { s.lida = true; mudou = true; } });
      if (mudou) write(d);
    },
    naoLidas: function (marca) { return read().solicitacoes.filter(function (s) { return s.marca === marca && !s.lida; }).length; },

    /* Aprovação de demandas: chave = marca:idDaDemanda */
    addAprovacao: function (chave, entrada) {
      var d = read(); var a = d.aprovacoes[chave] || { decisao: '', historico: [] };
      a.historico.push(entrada); if (entrada.decisao) a.decisao = entrada.decisao;
      d.aprovacoes[chave] = a; write(d);
    },

    /* Sessão (simulada) */
    acesso: function () {
      try { var a = JSON.parse(localStorage.getItem('hub_acesso')); if (a && a.marcas) return a; } catch (e) {}
      return null;
    },
    sair: function () { try { localStorage.removeItem('hub_acesso'); } catch (e) {} },
    limparTudo: function () { MEM = null; try { localStorage.removeItem(K); } catch (e) {} },
    fmtTam: function (n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  };

  /* Mídias das demandas (1 vídeo ou até 10 imagens): arquivo em IndexedDB, lista no registro da demanda */
  var UC = {};
  window.HubDB.addMidia = function (file, marca) {
    var id = uid('v'), caminho = 'midias/' + (marca || 'weduu') + '/' + id + '-' + String(file.name || 'midia').replace(/[^\w.\-]+/g, '_');
    return putBlob(id, file, caminho).then(function () {
      return { id: id, name: file.name, type: file.type || '', size: file.size, kind: /^video\//.test(file.type) ? 'video' : 'image', caminho: caminho };
    });
  };
  window.HubDB.midiaUrl = function (id) {
    if (/^seed-/.test(id)) return Promise.resolve(id + '.png'); /* mídias de demonstração = arquivos estáticos */
    if (UC[id]) return Promise.resolve(UC[id]);
    return getBlob(id).then(function (b) { if (!b) return ''; UC[id] = typeof b === 'string' ? b : URL.createObjectURL(b); return UC[id]; }).catch(function () { return ''; });
  };
  window.HubDB.setMidias = function (chave, lista) {
    var d = read(); d.midias = d.midias || {}; d.midias[chave] = lista; write(d);
  };
  window.HubDB.midias = function (chave) { var d = read(); var x = d.demandas && d.demandas[chave]; return (d.midias && d.midias[chave]) || (x && x.images) || []; };


  /* ---------- Demandas e decisões ----------
     NA VERSÃO FINAL: coleção `demandas/{marca}_{id}` no Firestore. A decisão grava em `aprovacoes/{marca}_{id}`
     e atualiza o `status` da demanda, para que o hub e a área do porta-voz enxerguem a mesma coisa. */
  var STATUS_POR_DECISAO = { Aprovado: 'Concluído', Ajuste: 'Em revisão', Reprovado: 'A fazer', Publicado: 'Concluído' };
  function marcaDe(co) { return co === 'Netpartners' ? 'netpartners' : 'weduu'; }
  function chaveDe(t) { return marcaDe(t.company) + ':' + t.id; }
  function dem(d) { d.demandas = d.demandas || {}; return d.demandas; }
  Object.assign(window.HubDB, {
    STATUS_POR_DECISAO: STATUS_POR_DECISAO, marcaDe: marcaDe, chaveDe: chaveDe,
    /* todas as demandas (das duas marcas), já sem as removidas */
    demandas: function () {
      var m = dem(read()); return Object.keys(m).filter(function (k) { return !m[k]._del; }).map(function (k) { return m[k]; });
    },
    demanda: function (chave) { var x = dem(read())[chave]; return x && !x._del ? x : null; },
    /* grava só o que mudou; devolve true se algo foi gravado */
    salvarDemanda: function (t) {
      var d = read(), k = chaveDe(t), m = dem(d), novo = JSON.stringify(t);
      if (m[k] && JSON.stringify(m[k]) === novo) return false;
      m[k] = JSON.parse(novo); write(d); return true;
    },
    removerDemanda: function (chave) { var d = read(); dem(d)[chave] = { _del: true, em: agora() }; write(d); },
    /* semeia demandas de demonstração que ainda não existem (e não foram apagadas) */
    garantirDemandas: function (lista) {
      if (semSeed) return; /* na versão final não há demonstração */
      var d = read(), m = dem(d), mudou = false;
      lista.forEach(function (t) { var k = chaveDe(t); if (!m[k]) { m[k] = JSON.parse(JSON.stringify(t)); mudou = true; } });
      if (mudou) write(d);
    },
    /* decisão ou comentário: registra no histórico e move o status da demanda */
    decidir: function (chave, entrada) {
      var d = read(), a = d.aprovacoes[chave] || { decisao: '', historico: [] };
      entrada.id = entrada.id || uid('d'); entrada.em = entrada.em || agora(); if (entrada.papel && entrada.papel !== 'Marketing') entrada.lida = false;
      a.historico.push(entrada); if (entrada.decisao) a.decisao = entrada.decisao;
      d.aprovacoes[chave] = a;
      var x = dem(d)[chave], ns = STATUS_POR_DECISAO[entrada.decisao];
      if (x && !x._del && ns) { x.status = ns; if (entrada.decisao === 'Publicado') x.publicadoEm = entrada.em; }
      write(d); return a;
    },
    aprovacao: function (chave) { return read().aprovacoes[chave] || { decisao: '', historico: [] }; },
    /* avisos de decisões/comentários vindos de fora do Marketing (porta-vozes) ainda não vistos */
    avisosDecisao: function () {
      var d = read(), out = [];
      Object.keys(d.aprovacoes).forEach(function (k) {
        var t = dem(d)[k], marca = k.split(':')[0];
        (d.aprovacoes[k].historico || []).forEach(function (h, i) {
          if (h.papel && h.papel !== 'Marketing' && h.lida === false) out.push({ chave: k, i: i, marca: marca, titulo: t && t.title || '', por: h.por, papel: h.papel, decisao: h.decisao, comentario: h.comentario, em: h.em, tarefa: t ? t.id : null });
        });
      });
      return out;
    },
    marcarDecisoesLidas: function (chaves) {
      var d = read(), mudou = false;
      Object.keys(d.aprovacoes).forEach(function (k) {
        if (chaves && chaves.indexOf(k) === -1) return;
        (d.aprovacoes[k].historico || []).forEach(function (h) { if (h.lida === false) { h.lida = true; mudou = true; } });
      });
      if (mudou) write(d);
    }
  });

  /* ---------- Usuários e níveis de acesso ----------
     NA VERSÃO FINAL: coleção `usuarios/{email}` no Firestore, gerida pela tela de configurações do administrador. */
  var DEST = {
    hub: 'minha-area.html',
    fin: 'financeiro.html',
    apr: 'portavoz-weduu.html',
    pvnet: 'portavoz-net.html'
  };
  var NIVEIS = [
    { id: 'marketing', label: 'Marketing (hub interno)', desc: 'Entra em Minha área e no hub da(s) empresa(s) escolhida(s).', marcas: 'escolher', aprova: true },
    { id: 'dashboards', label: 'Somente dashboards', desc: 'Vê apenas a aba Dashboards da(s) empresa(s) escolhida(s).', marcas: 'escolher' },
    { id: 'portavoz_weduu', label: 'Porta-voz Weduu', desc: 'Só a página de aprovação de porta-vozes da Weduu.', marcas: ['weduu'] },
    { id: 'portavoz_net', label: 'Porta-voz Netpartners', desc: 'Só a área de porta-vozes da Netpartners.', marcas: ['netpartners'] },
    { id: 'financeiro', label: 'Financeiro', desc: 'Só o Portal Financeiro (Weduu e Netpartners).', marcas: ['weduu', 'netpartners'] }
  ];
  var SEED = {
    'giovana@exemplo.com.br': { nome: 'Giovana Maldonado', nivel: 'marketing', marcas: ['weduu', 'netpartners'], aprovador: true, admin: true },
    'bruno@exemplo.com.br': { nome: 'Bruno', nivel: 'marketing', marcas: ['weduu', 'netpartners'], aprovador: true },
    'theo@exemplo.com': { nome: 'Théo', nivel: 'marketing', marcas: ['weduu', 'netpartners'], aprovador: true },
    'frizon@exemplo.com': { nome: 'Frizon', nivel: 'marketing', marcas: ['weduu', 'netpartners'] },
    'bruninho@exemplo.com': { nome: 'Bruninho', nivel: 'marketing', marcas: ['netpartners'] },
    'pricila@exemplo.com.br': { nome: 'Pricila', nivel: 'portavoz_weduu', marcas: ['weduu'] },
    'lucimara@exemplo.com.br': { nome: 'Lucimara', nivel: 'portavoz_weduu', marcas: ['weduu'] },
    'jessica@exemplo.com.br': { nome: 'Jéssica', nivel: 'financeiro', marcas: ['weduu', 'netpartners'] }
  };
  function nivelDe(id) { return NIVEIS.filter(function (n) { return n.id === id; })[0] || NIVEIS[0]; }
  function nomesMarcas(m) { return (m || []).map(function (x) { return MARCAS[x]; }).join(' e '); }
  function resumo(u) {
    var n = u.nivel;
    if (n === 'marketing') return 'Hub ' + (u.marcas.length > 1 ? 'da Weduu e da Netpartners' : 'da ' + nomesMarcas(u.marcas)) + (u.aprovador ? ', com aprovação de demandas' : '');
    if (n === 'dashboards') return 'Somente dashboards ' + (u.marcas.length > 1 ? 'da Weduu e da Netpartners' : 'da ' + nomesMarcas(u.marcas));
    if (n === 'portavoz_weduu') return 'Área de aprovação de porta-vozes da Weduu';
    if (n === 'portavoz_net') return 'Área de porta-vozes da Netpartners';
    if (n === 'financeiro') return 'Portal Financeiro (Weduu e Netpartners)';
    return '';
  }
  function todosUsuarios() {
    var d = read(), rem = d.removidos || [], out = [];
    if (!semSeed) Object.keys(SEED).forEach(function (e) { if (rem.indexOf(e) === -1) out.push(Object.assign({ email: e, seed: true }, SEED[e])); });
    var add = d.usuarios || {};
    Object.keys(add).forEach(function (e) { if (semSeed || !SEED[e]) out.push(Object.assign({ email: e }, add[e])); });
    return out;
  }
  function acessoDe(u) {
    var n = u.nivel;
    return {
      nome: u.nome, email: u.email, marcas: u.marcas, nivel: n, aprovador: !!u.aprovador && n === 'marketing', admin: !!u.admin,
      somenteDash: n === 'dashboards',
      destino: n === 'financeiro' ? DEST.fin : n === 'portavoz_weduu' ? DEST.apr : n === 'portavoz_net' ? DEST.pvnet : DEST.hub,
      titulo: n === 'financeiro' ? 'Abrindo o Portal Financeiro' : n === 'portavoz_weduu' ? 'Abrindo a aprovação de porta-vozes' : n === 'portavoz_net' ? 'Abrindo a área de porta-vozes' : n === 'dashboards' ? 'Abrindo os dashboards' : 'Abrindo Minha área'
    };
  }
  Object.assign(window.HubDB, {
    NIVEIS: NIVEIS, DEST: DEST, nivel: nivelDe, resumo: resumo,
    usuarios: todosUsuarios,
    usuario: function (email) {
      email = String(email || '').trim().toLowerCase();
      var u = todosUsuarios().filter(function (x) { return x.email === email; })[0];
      return u ? acessoDe(u) : null;
    },
    addUsuario: function (u) {
      var d = read(); d.usuarios = d.usuarios || {}; d.removidos = (d.removidos || []).filter(function (e) { return e !== u.email; });
      d.usuarios[u.email] = { nome: u.nome, nivel: u.nivel, marcas: u.marcas, aprovador: !!u.aprovador, admin: !!u.admin }; write(d);
    },
    removeUsuario: function (email) {
      var d = read(); if (d.usuarios) delete d.usuarios[email];
      d.removidos = d.removidos || []; if (SEED[email] && d.removidos.indexOf(email) === -1) d.removidos.push(email); write(d);
    },
    foto: function (email) { var d = read(); return (d.fotos && d.fotos[email]) || ''; },
    setFoto: function (email, url) { var d = read(); d.fotos = d.fotos || {}; if (url) d.fotos[email] = url; else delete d.fotos[email]; write(d); }
  });
})();
