/* HubDB no Firebase (Auth + Firestore + Storage).
   Carregue DEPOIS de hubdb.js. Nenhuma outra função do HubDB muda: as páginas continuam chamando
   HubDB.demandas(), HubDB.decidir(), HubDB.addMaterial() etc. Este arquivo só troca ONDE os dados ficam.

   Como funciona
   - Um cache em memória (mesmo formato do localStorage da versão de teste) é alimentado em tempo real
     por listeners do Firestore. As leituras continuam síncronas.
   - Toda gravação do HubDB atualiza o cache e este arquivo envia ao Firestore só os documentos que mudaram.
   - Arquivos vão para o Storage; o caminho fica no registro (`caminho`).

   Uso nas páginas (troca de 2 linhas):
     <script src="hubdb.js"></script>
     <script src="hubdb-firebase.js"></script>
     <script>
       HubDBFirebase.iniciar({ firebaseConfig: { ... } }).then(function () { ...código da página... });
     </script>
   Login: HubDBFirebase.entrarComGoogle() -> acesso (o mesmo objeto de HubDB.acesso()) ou erro 'sem-acesso'. */
(function () {
  var VERSAO = '10.12.2', BASE = 'https://www.gstatic.com/firebasejs/' + VERSAO + '/';
  var H = window.HubDB;
  var sdk, auth, db, storage, rev = 0, pronto = false;
  var cache = { materiais: [], solicitacoes: [], aprovacoes: {}, demandas: {}, usuarios: {}, fotos: {}, midias: {}, removidos: [] };
  var srv = { materiais: {}, solicitacoes: {}, demandas: {}, decisoes: {}, usuarios: {} };   // JSON de cada documento já conhecido
  var unsub = [], iniciando = null;

  function carregarSdk() {
    return Promise.all([import(BASE + 'firebase-app.js'), import(BASE + 'firebase-auth.js'), import(BASE + 'firebase-firestore.js'), import(BASE + 'firebase-storage.js')])
      .then(function (m) { return Object.assign({}, m[0], m[1], m[2], m[3]); });
  }
  var docId = function (chave) { return String(chave).replace(':', '_'); };
  function ordena(v) {
    if (Array.isArray(v)) return v.map(ordena);
    if (v && typeof v === 'object') { var r = {}; Object.keys(v).sort().forEach(function (k) { r[k] = ordena(v[k]); }); return r; }
    return v;
  }
  var json = function (o) { return JSON.stringify(ordena(o)); };
  function limpa(o) { var r = {}; Object.keys(o).forEach(function (k) { if (o[k] !== undefined) r[k] = o[k]; }); return r; }

  /* ---------- cache -> documentos ---------- */
  function paraDocs(d) {
    var out = { materiais: {}, solicitacoes: {}, demandas: {}, decisoes: {}, usuarios: {} };
    (d.materiais || []).forEach(function (m) { out.materiais[m.id] = limpa(m); });
    (d.solicitacoes || []).forEach(function (s) { out.solicitacoes[s.id] = limpa(s); });
    Object.keys(d.demandas || {}).forEach(function (k) {
      var x = d.demandas[k]; if (!x || x._del) return;
      out.demandas[docId(k)] = limpa(Object.assign({}, x, { marca: H.marcaDe(x.company) }));
    });
    Object.keys(d.aprovacoes || {}).forEach(function (k) {
      var dem = (d.demandas || {})[k] || {};
      ((d.aprovacoes[k] || {}).historico || []).forEach(function (h, i) {
        var id = h.id || (docId(k) + '_' + i);
        out.decisoes[id] = limpa(Object.assign({}, h, { id: id, chave: k, marca: k.split(':')[0], aprovadores: dem.approvers || [] }));
      });
    });
    Object.keys(d.usuarios || {}).forEach(function (e) {
      var u = Object.assign({ ativo: true }, d.usuarios[e]);
      if (d.fotos && d.fotos[e] !== undefined) u.foto = d.fotos[e];
      out.usuarios[e] = limpa(u);
    });
    return out;
  }
  /* ---------- documentos -> cache ---------- */
  function paraCache() {
    var d = { materiais: [], solicitacoes: [], aprovacoes: {}, demandas: {}, usuarios: {}, fotos: {}, midias: {}, removidos: [] };
    Object.keys(srv.materiais).forEach(function (i) { d.materiais.push(JSON.parse(srv.materiais[i])); });
    Object.keys(srv.solicitacoes).forEach(function (i) { d.solicitacoes.push(JSON.parse(srv.solicitacoes[i])); });
    d.materiais.sort(function (a, b) { return String(b.em).localeCompare(String(a.em)); });
    d.solicitacoes.sort(function (a, b) { return String(b.em).localeCompare(String(a.em)); });
    Object.keys(srv.demandas).forEach(function (i) { var x = JSON.parse(srv.demandas[i]); d.demandas[H.chaveDe(x)] = x; });
    var hs = Object.keys(srv.decisoes).map(function (i) { return JSON.parse(srv.decisoes[i]); }).sort(function (a, b) { return String(a.em).localeCompare(String(b.em)); });
    hs.forEach(function (h) {
      var a = d.aprovacoes[h.chave] || (d.aprovacoes[h.chave] = { decisao: '', historico: [] });
      a.historico.push(h); if (h.decisao) a.decisao = h.decisao;
    });
    Object.keys(srv.usuarios).forEach(function (e) {
      var u = JSON.parse(srv.usuarios[e]); if (u.foto !== undefined) d.fotos[e] = u.foto; delete u.foto; d.usuarios[e] = u;
    });
    return d;
  }
  function bump() { cache = paraCache(); rev++; }

  /* ---------- gravação: só o que mudou ---------- */
  var aguardando = [];
  function gravar(d) {
    if (!sdk) {   // gravação antes do SDK carregar: vale no cache e vai ao Firestore assim que ficar pronto (só cria/atualiza, nunca apaga)
      cache = d; rev++; aguardando.push(d); return d;
    }
    return gravarAgora(d, false);
  }
  function gravarAgora(d, soCriar) {
    var novo = paraDocs(d), col = { materiais: 'materiais', solicitacoes: 'solicitacoes', demandas: 'demandas', decisoes: 'decisoes', usuarios: 'usuarios' };
    var tarefas = [];
    Object.keys(col).forEach(function (c) {
      Object.keys(novo[c]).forEach(function (id) {
        var j = json(novo[c][id]);
        if (srv[c][id] !== j) {
          srv[c][id] = j;
          tarefas.push(sdk.setDoc(sdk.doc(db, col[c], id), novo[c][id]));
        }
      });
      Object.keys(srv[c]).forEach(function (id) {
        if (!soCriar && !novo[c][id]) { delete srv[c][id]; tarefas.push(sdk.deleteDoc(sdk.doc(db, col[c], id))); }
      });
    });
    if (!soCriar) bump();
    Promise.all(tarefas).catch(function (e) { console.error('[HubDB] falha ao gravar no Firestore', e); if (H.aoErro) H.aoErro(e); });
    return d;
  }

  /* ---------- arquivos ---------- */
  function caminhoDe(id) {
    var m = cache.materiais.filter(function (x) { return x.id === id; })[0]; if (m) return m.caminho;
    var achado = '';
    Object.keys(cache.demandas).forEach(function (k) { ((cache.demandas[k].images) || []).forEach(function (im) { if (im && im.id === id) achado = im.caminho; }); });
    return achado;
  }
  var urls = {};
  var liberar, aberto = new Promise(function (ok) { liberar = ok; });
  function putBlob(id, blob, caminho) {
    return aberto.then(function () {
      var r = sdk.ref(storage, caminho);
      return sdk.uploadBytes(r, blob, { contentType: blob.type || undefined }).then(function () { return sdk.getDownloadURL(r); }).then(function (u) { urls[id] = u; });
    });
  }
  function getBlob(id) {
    if (urls[id]) return Promise.resolve(urls[id]);
    return aberto.then(function () { return getBlobPronto(id); });
  }
  function getBlobPronto(id) {
    var c = caminhoDe(id); if (!c) return Promise.resolve(null);
    return sdk.getDownloadURL(sdk.ref(storage, c)).then(function (u) { urls[id] = u; return u; }).catch(function () { return null; });
  }
  function delBlob(id) { return aberto.then(function () { var c = caminhoDe(id); return c ? sdk.deleteObject(sdk.ref(storage, c)).catch(function () {}) : null; }); }

  // o armazenamento é trocado assim que este arquivo carrega, para a página nunca gravar no localStorage por engano
  H._usarStore({ read: function () { return cache; }, write: gravar, raw: function () { return String(rev); }, putBlob: putBlob, getBlob: getBlob, delBlob: delBlob, semSeed: true });

  /* ---------- listeners em tempo real, de acordo com o nível da pessoa ---------- */
  function escutar(acesso) {
    unsub.forEach(function (f) { f(); }); unsub = [];
    var W = sdk.where, Q = sdk.query, C = sdk.collection;
    var primeiro = String(acesso.nome || '').split(' ')[0];
    var consultas = [];   // [coleção, query]
    var marcas = acesso.marcas || [];
    function escuta(nome, q, chaveSrv) {
      unsub.push(sdk.onSnapshot(q, function (snap) {
        if (!snap.docChanges) {   // listener de um único documento
          if (snap.exists()) srv[chaveSrv][snap.id] = json(snap.data()); else delete srv[chaveSrv][snap.id];
          bump(); return;
        }
        snap.docChanges().forEach(function (ch) {
          var id = ch.doc.id;
          if (ch.type === 'removed') delete srv[chaveSrv][id]; else srv[chaveSrv][id] = json(ch.doc.data());
        });
        bump();
      }, function (e) { console.error('[HubDB] sem permissão em ' + nome, e); }));
    }
    escuta('usuarios', sdk.doc(db, 'usuarios', acesso.email), 'usuarios');
    if (acesso.admin) escuta('usuarios', C(db, 'usuarios'), 'usuarios');
    escuta('materiais', C(db, 'materiais'), 'materiais');
    if (acesso.nivel === 'marketing') {
      escuta('solicitacoes', Q(C(db, 'solicitacoes'), W('marca', 'in', marcas)), 'solicitacoes');
      escuta('demandas', Q(C(db, 'demandas'), W('marca', 'in', marcas)), 'demandas');
      escuta('decisoes', Q(C(db, 'decisoes'), W('marca', 'in', marcas)), 'decisoes');
    } else if (acesso.nivel === 'portavoz_weduu' || acesso.nivel === 'portavoz_net') {
      var m = acesso.nivel === 'portavoz_weduu' ? 'weduu' : 'netpartners';
      escuta('demandas', Q(C(db, 'demandas'), W('marca', '==', m), W('approvers', 'array-contains', primeiro)), 'demandas');
      escuta('decisoes', Q(C(db, 'decisoes'), W('marca', '==', m), W('aprovadores', 'array-contains', primeiro)), 'decisoes');
    }
  }

  /* ---------- API pública ---------- */
  function acessoDoCadastro(c) { return H.usuario(c.email); }
  var API = window.HubDBFirebase = {
    iniciar: function (opts) {
      if (iniciando) return iniciando;   // pode ser chamado por mais de uma página/script sem iniciar duas vezes
      iniciando = (opts.sdk ? Promise.resolve(opts.sdk) : carregarSdk()).then(function (s) {
        sdk = s; var app = sdk.initializeApp(opts.firebaseConfig);
        auth = sdk.getAuth(app); db = sdk.getFirestore(app); storage = sdk.getStorage(app);
        liberar();
        aguardando.splice(0).forEach(function (d) { gravarAgora(d, true); });
        // sessão: quando já há login, restaura o acesso e liga os listeners
        return new Promise(function (ok) {
          var primeira = true;
          sdk.onAuthStateChanged(auth, function (u) {
            var fim = function () { if (primeira) { primeira = false; pronto = true; ok(H.acesso()); } };
            if (!u) { try { localStorage.removeItem('hub_acesso'); } catch (e) {} fim(); return; }
            API._carregarAcesso(u.email).then(function (a) { if (a) escutar(a); fim(); }).catch(fim);
          });
        });
      });
      return iniciando;
    },
    /* lê o cadastro (/usuarios/{email}); se não existir ou estiver inativo, desloga e devolve null */
    _carregarAcesso: function (email) {
      email = String(email || '').toLowerCase();
      return sdk.getDoc(sdk.doc(db, 'usuarios', email)).then(function (snap) {
        var c = snap.exists() ? snap.data() : null;
        if (!c || c.ativo === false) { try { localStorage.removeItem('hub_acesso'); } catch (e) {} return sdk.signOut(auth).then(function () { return null; }); }
        srv.usuarios[email] = json(c); bump();
        var a = acessoDoCadastro(Object.assign({ email: email }, c));
        try { localStorage.setItem('hub_acesso', JSON.stringify(a)); } catch (e) {}
        return a;
      });
    },
    entrarComGoogle: function () {
      return sdk.signInWithPopup(auth, new sdk.GoogleAuthProvider()).then(function (r) {
        return API._carregarAcesso(r.user.email).then(function (a) {
          if (!a) { var e = new Error('sem-acesso'); e.code = 'sem-acesso'; throw e; }
          escutar(a); return a;
        });
      });
    },
    sair: function () { unsub.forEach(function (f) { f(); }); unsub = []; try { localStorage.removeItem('hub_acesso'); } catch (e) {} return sdk ? sdk.signOut(auth) : Promise.resolve(); },
    pronto: function () { return pronto; }
  };
})();
