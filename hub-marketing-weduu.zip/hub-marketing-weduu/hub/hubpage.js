/* Conteúdo das páginas internas dos sites públicos: pasta de materiais e solicitação ao Marketing.
   Lê a marca e a página do <body data-marca data-page>. */
(function () {
  var B = document.body, marca = B.getAttribute('data-marca'), pagina = B.getAttribute('data-page');
  var nome = HubDB.MARCAS[marca];
  var $ = function (i) { return document.getElementById(i); };
  var main = $('pg-main');
  var q = new URLSearchParams(location.search);

  function titulo(txt, destaque) {
    var h = $('pg-h1'); h.textContent = '';
    if (!destaque) { h.textContent = txt; return; }
    h.appendChild(document.createTextNode(txt + ' '));
    var s = document.createElement('span');
    if (marca === 'netpartners') s.className = 'c-blue';
    s.textContent = destaque; h.appendChild(s);
  }
  function ativarNav(href) {
    document.querySelectorAll('header a').forEach(function (a) { if (a.getAttribute('href') === href) a.classList.add(marca === 'weduu' ? 'active' : 'pill'); });
  }

  if (pagina === 'pasta') {
    var pasta = q.get('pasta'); if (!HubDB.PASTAS[pasta]) pasta = 'marca';
    document.title = HubDB.PASTAS[pasta] + ' | ' + nome;
    var partes = HubDB.PASTAS[pasta].split(' ');
    var ult = partes.pop(); titulo(partes.join(' '), ult);
    if (!partes.length) titulo('', ''), $('pg-h1').innerHTML = '<span' + (marca === 'netpartners' ? ' class="c-blue"' : '') + '>' + ult + '</span>';
    $('pg-sub').textContent = 'Arquivos oficiais da ' + nome + ' publicados pelo time de Marketing.';
    ativarNav(pasta === 'ajuda' ? 'pasta-' + marca + '.html?pasta=ajuda' : marca + '.html#materiais');
    main.innerHTML = '<div class="pg-tabs" id="tabs"></div><div class="pg-list" id="lista"></div><div class="pg-cta"><a class="pg-btn ac" href="solicitar-' + marca + '.html">Não achou? Solicitar ao Marketing</a></div>';
    Object.keys(HubDB.PASTAS).forEach(function (k) {
      var a = document.createElement('a'); a.href = 'pasta-' + marca + '.html?pasta=' + k; a.textContent = HubDB.PASTAS[k]; if (k === pasta) a.className = 'on'; $('tabs').appendChild(a);
    });
    var ext = function (n) { var m = /\.([a-z0-9]{1,4})$/i.exec(n); return m ? m[1] : 'arq'; };
    var abrir = function (m, baixar) {
      HubDB.getBlob(m.id).then(function (b) {
        if (!b) { alert('Arquivo indisponível no momento.'); return; }
        var eUrl = typeof b === 'string', u = eUrl ? b : URL.createObjectURL(b), a = document.createElement('a'); a.href = u;
        if (baixar) a.download = m.nome; else a.target = '_blank';
        a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove(); if (!eUrl) setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
      });
    };
    var render = function () {
      var itens = HubDB.materiais(marca, pasta), l = $('lista'); l.innerHTML = '';
      if (!itens.length) { l.innerHTML = '<div class="pg-empty">Ainda não há arquivos nesta pasta.</div>'; return; }
      itens.forEach(function (m) {
        var r = document.createElement('div'); r.className = 'pg-row';
        r.innerHTML = '<div class="pg-ic"></div><div class="pg-nm"><b></b><span></span></div>';
        r.querySelector('.pg-ic').textContent = ext(m.nome);
        r.querySelector('b').textContent = m.nome;
        r.querySelector('span').textContent = HubDB.fmtTam(m.tamanho) + ' · enviado em ' + new Date(m.em).toLocaleDateString('pt-BR');
        var v = document.createElement('button'); v.className = 'pg-btn o'; v.textContent = 'Abrir'; v.onclick = function () { abrir(m, false); };
        var d = document.createElement('button'); d.className = 'pg-btn'; d.textContent = 'Baixar'; d.onclick = function () { abrir(m, true); };
        r.appendChild(v); r.appendChild(d); l.appendChild(r);
      });
    };
    render(); setInterval(render, 4000);
  }

  if (pagina === 'solicitar') {
    document.title = 'Solicitar ao Marketing | ' + nome;
    titulo('Solicitar ao', 'Marketing');
    $('pg-sub').textContent = 'Peça um material, abra uma demanda ou tire uma dúvida com o time.';
    ativarNav('solicitar-' + marca + '.html');
    main.innerHTML =
      '<div class="pg-form" id="form"><form id="f" novalidate>' +
      '<div class="pg-g"><div class="pg-f"><label for="nome">Seu nome</label><input id="nome" autocomplete="name"></div>' +
      '<div class="pg-f"><label for="email">Seu e-mail</label><input id="email" type="email" autocomplete="email"></div></div>' +
      '<div class="pg-g"><div class="pg-f"><label for="tipo">Tipo de pedido</label><select id="tipo"><option>Material novo</option><option>Ajuste em material existente</option><option>Case ou história</option><option>Dúvida</option><option>Outro</option></select></div>' +
      '<div class="pg-f"><label for="prazo">Prazo desejado (opcional)</label><input id="prazo" type="date"></div></div>' +
      '<div class="pg-f"><label for="titulo">Resumo do pedido</label><input id="titulo" maxlength="140" placeholder="Ex.: Banner para a página de vagas"></div>' +
      '<div class="pg-f"><label for="desc">Detalhes</label><textarea id="desc" placeholder="Conte o contexto, formato, público e onde será usado."></textarea></div>' +
      '<p class="pg-err" id="err"></p><button class="pg-btn ac" type="submit" style="padding:14px 28px;font-size:13px">Enviar solicitação</button></form></div>' +
      '<div class="pg-ok" id="ok" hidden><div class="ck">✓</div><h2>Solicitação enviada!</h2><p>Protocolo <b id="pr"></b>. O time de Marketing da ' + nome + ' já foi avisado.</p><a href="#" id="novo">Fazer outra solicitação</a></div>';
    var a = HubDB.acesso(); if (a) $('nome').value = a.nome || '';
    $('f').addEventListener('submit', function (e) {
      e.preventDefault();
      var nm = $('nome').value.trim(), em = $('email').value.trim(), ti = $('titulo').value.trim();
      if (!nm || !/^\S+@\S+\.\S+$/.test(em) || !ti) { $('err').textContent = 'Preencha nome, um e-mail válido e o resumo do pedido.'; return; }
      $('err').textContent = '';
      var r = HubDB.addSolicitacao({ marca: marca, nome: nm, email: em, tipo: $('tipo').value, titulo: ti, descricao: $('desc').value.trim(), prazo: $('prazo').value });
      $('pr').textContent = r.protocolo; $('form').hidden = true; $('ok').hidden = false;
    });
    $('novo').addEventListener('click', function (e) { e.preventDefault(); $('f').reset(); $('ok').hidden = true; $('form').hidden = false; });
  }
})();
